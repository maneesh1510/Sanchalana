<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title> College Event Management</title>
</head>
<body bgcolor="lightblue">
<img src="images\logo1.jpg">
<BR>

<a href="mainpage.php"> <h3> Home </h3></A>        
<center><img src="images\studentmain.bmp"></center>
<BR>
<Table border="0" align="center" width="50%" cellpadding="5">

<tr><td height="20" bgcolor="#33AABB" >    
<A href="studenteventtypelist.php"> <h2>  Event Type List </h2> </A> 
</td></tr>

<tr><td height="20" bgcolor="#55AABB">    
<A href="studenteventlist.php"> <h2> Event List </h2> </A>
</td></tr>


<tr><td height="20" bgcolor="#55AABB">    
<A href="studentapply1.php"> <h2> Event Apply </h2> </A>
</td></tr>

<tr><td height="20" bgcolor="#55AABB">    
<A href="studentappliedlist.php"> <h2> Event Applied List </h2> </A>
</td></tr>




</table>    
<?php
// put your code here
?>
<BR>
<BR>

</body>
</html>
