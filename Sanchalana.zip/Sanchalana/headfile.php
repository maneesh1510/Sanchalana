<html>
    <head>
          <style type="text/css">
            label{ margin-right:20px;}
            input{ margin-top:5px;}
        </style>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Online Event Management</title>
        
       
    

    </head>
    <body bgcolor="lightblue" >
        <img style="-webkit-user-select: none" src="images/logo1.jpg">
        
    </body>
</html>