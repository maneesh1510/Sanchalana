<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title> Online Event Management</title>
    </head>
     <body bgcolor="lightblue">
        <img src="images\logo1.jpg">
        <BR>
        
        <a href="mainpage.php"> <h3> Logout </h3></A>        
     <center><img src="images\adminmain.bmp"></center>
        <BR>
        <Table border="0" align="center" width="50%" cellpadding="5">
        <tr><td height="20" bgcolor="#33AABB" >    
                <A href="admincourse.php"> <h2>  Course Entry </h2> </A> </td><td bgcolor="#33AABB"> <A href="admincourselist.php"> <h2>  List </h2> </A>
        </td></tr>
       
                    <tr><td  bgcolor="#33AABB">    
        <A href="adminstudent.php"> <h2>  Student Details </h2> </A> </td><td bgcolor="#33AABB"> <A href="adminstudentlist.php"> <h2>  Student List </h2> </A>
        </td></tr>
                <tr><td  bgcolor="#33AABB">    
        <A href="admineventtype.php"> <h2>  Event Type Details</h2>  </A> </td><td bgcolor="#33AABB"> <A href="admineventtypelist.php"> <h2>  Event Type List </h2> </A>
        </td></tr>
                
        <tr><td  bgcolor="#33AABB">    
        <A href="adminevent.php"> <h2> Event Details </h2> </A> </td><td bgcolor="#33AABB"> <A href="admineventlist.php"> <h2> Event List </h2> </A>
        </td></tr>
        
        <tr><td  bgcolor="#33AABB">    
        <A href="adminappliedlist.php"> <h2> Applicant List </h2> </A> </td><td bgcolor="#33AABB"> <A href="adminindex.php"> <h2> Logout </h2> </A> 
        </td></tr>        


                           
        </table>    
        <?php
        // put your code here
        ?>
        <BR>
        <BR>
      
    </body>
</html>

